from __future__ import annotations

from autotoken.api_routes.account_exports import AccountCredentialExportParams, create_account_exports_router
from autotoken.api_routes.account_management import AccountExternalImportParams, create_account_management_router
from autotoken.storage import accounts as account_store


class _NoopLock:
    def acquire(self, blocking=False):
        return False

    def release(self):
        pass


class _NoopExecutor:
    def run(self, func, *args, **kwargs):
        return func(*args, **kwargs)


def _endpoint(router, path: str):
    return next(route.endpoint for route in router.routes if route.path == path)


def _normalize(email):
    return account_store._normalized_email(email)


def _sanitize(account):
    return dict(account or {})


def _is_main(_email):
    return False


def _isolate_accounts(monkeypatch, tmp_path):
    monkeypatch.setattr(account_store, "ACCOUNTS_FILE", str(tmp_path / "accounts.json"))


def test_export_credentials_uses_three_part_2fa_format_for_enabled_accounts(monkeypatch, tmp_path):
    _isolate_accounts(monkeypatch, tmp_path)
    account_store.add_account("Pro2x-0906@nbclas.com", "EaD5zylT23wAJv")
    account_store.save_totp_metadata(
        "Pro2x-0906@nbclas.com",
        secret="MSRVASZAW32OYTLQOUXK625IXPCMKPAW",
    )

    router = create_account_exports_router(
        normalize_email=_normalize,
        is_main_account_email=_is_main,
        sanitize_account=_sanitize,
    )
    response = _endpoint(router, "/api/accounts/export-credentials")(
        AccountCredentialExportParams(emails=["Pro2x-0906@nbclas.com"])
    )

    assert response["content"] == "pro2x-0906@nbclas.com----EaD5zylT23wAJv----MSRVASZAW32OYTLQOUXK625IXPCMKPAW"
    assert response["format"] == "{email}----{password}----{totp_secret} when TOTP is enabled"
    assert response["totp_included"] is True


def test_import_external_accounts_accepts_password_2fa_format_and_marks_enabled(monkeypatch, tmp_path):
    _isolate_accounts(monkeypatch, tmp_path)
    router = create_account_management_router(
        playwright_lock=_NoopLock(),
        playwright_executor=_NoopExecutor(),
        current_busy_detail=lambda _email: None,
        is_main_account_email=_is_main,
        sanitize_account=_sanitize,
    )

    response = _endpoint(router, "/api/accounts/import-external")(
        AccountExternalImportParams(
            text="Pro2x-0906@nbclas.com----EaD5zylT23wAJv----MSRVASZAW32OYTLQOUXK625IXPCMKPAW"
        )
    )

    assert response["imported"] == 1
    assert response["totp_imported"] == 1
    account = account_store.find_account(account_store.load_accounts(), "Pro2x-0906@nbclas.com")
    assert account["password"] == "EaD5zylT23wAJv"
    assert account["two_factor_enabled"] is True
    assert account["totp_status"] == account_store.TOTP_STATUS_ENABLED
    assert account["totp_secret_masked"]
    assert account_store.get_totp_credentials("Pro2x-0906@nbclas.com")["secret"] == "MSRVASZAW32OYTLQOUXK625IXPCMKPAW"
    assert response["accounts"][0]["two_factor_enabled"] is True
    assert response["accounts"][0]["totp_status"] == account_store.TOTP_STATUS_ENABLED
