import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const dashboardSource = readFileSync(path.resolve(here, '../src/components/Dashboard.vue'), 'utf8')
const importModal = dashboardSource.match(/<!-- 外部账号导入弹窗 -->[\s\S]*?<\/AccessibleModal>/)?.[0] || ''
const submitExternalImport = dashboardSource.match(/async function submitExternalAccountImport\(\)[\s\S]*?function openCpaImport/)?.[0] || ''

assert.match(
  importModal,
  /邮箱----密码----2FA密钥/,
  '导入账号弹窗应说明支持 2FA 三段格式',
)
assert.match(
  importModal,
  /Pro2x-0906@nbclas\.com----EaD5zylT23wAJv----MSRVASZAW32OYTLQOUXK625IXPCMKPAW/,
  '导入账号输入框应展示 2FA 三段格式示例',
)
assert.match(
  importModal,
  /externalAccountImportResult\.totp_imported/,
  '导入结果应显示本次导入的 2FA 数量',
)
assert.match(
  submitExternalImport,
  /for \(const account of result\.accounts \|\| \[\]\)[\s\S]*accountTwoFactorEnabled\(account\)[\s\S]*completed\.add\(email\)[\s\S]*twoFactorCompletedEmails\.value = completed/,
  '导入返回启用 2FA 的账号后，应立即更新本地已设置状态',
)

console.log('dashboard 2FA import format regression passed')
