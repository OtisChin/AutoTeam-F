from autotoken.core.task_snapshots import task_list_snapshot


def test_setup_2fa_compact_task_keeps_target_emails_for_dashboard_running_state():
    task = {
        "task_id": "task-2fa",
        "command": "setup-2fa",
        "status": "running",
        "created_at": 1,
        "params": {"emails": ["one@example.com", "two@example.com"]},
    }

    snapshot = task_list_snapshot(task)

    assert snapshot["params"]["emails"] == ["one@example.com", "two@example.com"]
    assert snapshot["params"]["emails_count"] == 2
