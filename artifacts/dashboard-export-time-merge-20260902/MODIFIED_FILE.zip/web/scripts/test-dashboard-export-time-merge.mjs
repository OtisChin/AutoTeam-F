import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const dashboardSource = readFileSync(path.resolve(here, '../src/components/Dashboard.vue'), 'utf8')
const headerRow = dashboardSource.match(/<thead>[\s\S]*?<\/thead>/)?.[0] || ''
const accountRowTemplate = dashboardSource.match(/<tr v-for="\(acc, i\) in paginatedAccounts"[\s\S]*?<\/tr>/)?.[0] || ''
const exportCellMatch = accountRowTemplate.match(/<td class="px-4 py-3">\s*<div class="inline-flex flex-col items-start gap-1">[\s\S]*?credentialExportLabel\(acc\)[\s\S]*?<\/div>\s*<\/td>/)

assert.doesNotMatch(
  headerRow,
  /<th class="[^"]*font-medium[^"]*">导出时间<\/th>/,
  '导出时间不应再作为独立表头列展示',
)
assert.ok(exportCellMatch, '账号行应保留账密导出状态单元格')
assert.match(
  exportCellMatch[0],
  /v-if="acc\?\.credentials_exported && accountExportTs\(acc\)"[\s\S]*exportTimeLabel\(acc\)/,
  '已导出账号的导出时间应显示在“已导出”标识下面',
)
assert.doesNotMatch(
  accountRowTemplate,
  /<td class="px-4 py-3 text-gray-400 text-xs font-mono">\{\{ exportTimeLabel\(acc\) \}\}<\/td>/,
  '导出时间不应保留独立账号行单元格',
)
assert.match(
  dashboardSource,
  /colspan="14">没有匹配的账号/,
  '空状态应覆盖合并后的 14 列',
)

console.log('dashboard export time merge regression passed')
