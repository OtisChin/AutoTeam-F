import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const dashboardSource = readFileSync(path.resolve(here, '../src/components/Dashboard.vue'), 'utf8')
const accountRowTemplate = dashboardSource.match(/<tr v-for="\(acc, i\) in paginatedAccounts"[\s\S]*?<\/tr>/)?.[0] || ''

assert.match(
  accountRowTemplate,
  /displayEmailPreview\(acc\)[\s\S]*v-if="hasCodexAuthFile\(acc\)"[\s\S]*OAuth/,
  'accounts that already have OAuth credentials should show an OAuth badge next to the account email',
)
assert.match(
  accountRowTemplate,
  /title="该账号已有 OAuth 凭证"/,
  'the OAuth badge should explain why it is visible',
)
assert.match(
  accountRowTemplate,
  /v-memo="\[[^\"]*hasCodexAuthFile\(acc\)[^\"]*\]"/,
  'the account row memo should include the OAuth credential badge state',
)

console.log('dashboard OAuth badge regression passed')
