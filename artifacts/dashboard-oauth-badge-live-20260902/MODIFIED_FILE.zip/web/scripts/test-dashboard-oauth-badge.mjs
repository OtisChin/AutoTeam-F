import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const dashboardSource = readFileSync(path.resolve(here, '../src/components/Dashboard.vue'), 'utf8')
const accountRowTemplate = dashboardSource.match(/<tr v-for="\(acc, i\) in paginatedAccounts"[\s\S]*?<\/tr>/)?.[0] || ''

assert.match(
  accountRowTemplate,
  /displayEmailPreview\(acc\)[\s\S]*v-if="hasCodexAuthFile\(acc\)"[\s\S]*OAuth/,
  'accounts that already have OAuth credentials should show an OAuth badge next to the account email',
)
assert.match(
  accountRowTemplate,
  /title="该账号已有 OAuth 凭证"/,
  'the OAuth badge should explain why it is visible',
)
assert.match(
  accountRowTemplate,
  /v-memo="\[[^\"]*hasCodexAuthFile\(acc\)[^\"]*\]"/,
  'the account row memo should include the OAuth credential badge state',
)
assert.match(
  dashboardSource,
  /const oauthCredentialCompletedEmails = ref\(new Set\(\)\)/,
  'OAuth login completion should be tracked locally so the badge appears before a full page reload',
)
assert.match(
  dashboardSource,
  /function applyOAuthCredentialTaskProgressEvents\(tasks\)[\s\S]*stage === 'account_login_done'[\s\S]*completed\.add\(email\)/,
  'Dashboard should mark each account as having OAuth credentials when its login task emits account_login_done',
)
assert.match(
  dashboardSource,
  /String\(task\?\.status \|\| ''\) === 'completed' && String\(task\?\.result\?\.auth_file \|\| ''\)\.trim\(\)/,
  'single-account OAuth completion should only light the badge when the task result contains an auth_file',
)
assert.match(
  dashboardSource,
  /function hasCodexAuthFile\(acc\)[\s\S]*oauthCredentialCompletedEmails\.value\.has/,
  'the OAuth badge helper should include locally completed OAuth login emails',
)

console.log('dashboard OAuth badge regression passed')
