from autotoken.core.task_snapshots import task_list_snapshot


def test_setup_2fa_compact_task_keeps_target_emails_for_dashboard_running_state():
    task = {
        "task_id": "task-2fa",
        "command": "setup-2fa",
        "status": "running",
        "created_at": 1,
        "params": {"emails": ["one@example.com", "two@example.com"]},
    }

    snapshot = task_list_snapshot(task)

    assert snapshot["params"]["emails"] == ["one@example.com", "two@example.com"]
    assert snapshot["params"]["emails_count"] == 2


def test_setup_2fa_compact_task_keeps_account_completion_events_for_incremental_dashboard_state():
    task = {
        "task_id": "task-2fa",
        "command": "setup-2fa",
        "status": "running",
        "created_at": 1,
        "params": {"emails": ["one@example.com", "two@example.com", "three@example.com"]},
        "progress_events": [
            {"stage": "account_2fa_account_started", "email": "one@example.com", "message": "start"},
            {
                "stage": "account_2fa_progress",
                "email": "one@example.com",
                "status": "enabled",
                "reason": "",
                "message": "enabled",
            },
            {
                "stage": "account_2fa_progress",
                "email": "two@example.com",
                "status": "failed",
                "reason": "otp_timeout",
                "message": "failed",
            },
            {"stage": "gopay_progress", "email": "ignored@example.com", "status": "enabled"},
        ],
    }

    snapshot = task_list_snapshot(task)

    assert snapshot["progress_events"] == [
        {"stage": "account_2fa_progress", "email": "one@example.com", "status": "enabled", "reason": ""},
        {"stage": "account_2fa_progress", "email": "two@example.com", "status": "failed", "reason": "otp_timeout"},
    ]
