# OAuth Relogin Standalone Module

这是从当前项目复制/抽取出来的**脱敏独立版 OAuth 补登录模块**。它不依赖当前项目的账号池、任务系统、CPA 同步、邮箱供应商实现或数据库。

## 文件

- `oauth_relogin.py`：核心 Python 模块
- `oauth_helper_extension/`：浏览器辅助扩展，负责填邮箱/密码/OTP 并回传本地 helper 事件
- `.env.example`：可复制到目标项目的配置模板

## 能不能跑完整链路？

模块现在包含完整编排入口：

```python
from standalone.oauth_relogin import JsonPhonePoolProvider, run_oauth_relogin_flow

phone_pool = JsonPhonePoolProvider("data/phone-pool.json")
phone_pool.import_phones("+12025550111----https://sms.example/inbox/1")

result = run_oauth_relogin_flow(
    email="user@example.com",
    password="your-password",
    output_dir="data/oauth-output",
    bind_phone=True,
    sms_provider=phone_pool,
    phone_code_provider=lambda phone_item: "123456",
    oauth_runner=your_browser_or_protocol_runner,
)
```

成功后会写：

- `data/oauth-output/auths/oauth-user@example.com.json`
- `data/oauth-output/phone-bindings.json`
- `data/phone-pool.json` 中该号码的绑定计数和绑定邮箱

其中 `oauth_runner` 是目标项目要接入的登录/浏览器自动化函数。它会收到：

- `email`
- `password`
- `config`
- `phone_item`
- `get_phone_code`
- `proxy_url`

它需要在页面遇到 add-phone 时填写 `phone_item.phone_number`，然后调用 `get_phone_code()` 获取接码验证码，最终返回 token bundle。

## 快速接入

```python
from standalone.oauth_relogin import OAuthConfig, exchange_auth_code, generate_pkce, build_authorization_url

config = OAuthConfig.from_env()
verifier, challenge = generate_pkce()
auth_url = build_authorization_url(config, code_challenge=challenge, state="your-random-state")
print(auth_url)

# 用户登录后把 redirect_uri 回调里的 code 传回来：
bundle = exchange_auth_code("AUTH_CODE_FROM_CALLBACK", verifier, config=config)
```

## 纯协议补登录

如果目标项目已经保存了可复用 `auth_session` / cookie：

```python
from standalone.oauth_relogin import OAuthConfig, oauth_from_auth_session

bundle = oauth_from_auth_session(
    saved_auth_session,
    config=OAuthConfig.from_env(),
    email="user@example.com",
    proxy_url=None,
)
```

## 脱敏说明

- 默认 OAuth 域名是 `auth.example.com`
- 默认 `client_id` 是 `REPLACE_WITH_OAUTH_CLIENT_ID`
- helper 扩展使用 `oauth_relogin_*` 配置键，不包含原项目名称
- 不复制 `.env`、账号数据、auth 文件、日志、代理池或任何运行态数据

## 已内置

- OAuth 配置读取
- 接码配置读取与脱敏展示
- JSON 手机号池导入/预约/绑定计数
- token JSON 落盘
- 手机号绑定记录 JSON 落盘
- 协议 auth_session OAuth runner
- 浏览器 helper extension

## 需要目标项目自行接上的部分

- 真实浏览器登录/页面自动化 runner，或直接传入现有 `auth_session`
- 外部接码商 API adapter（如果不用 JSON 手机号池）
- 邮箱 OTP 获取逻辑
- 账号池状态回写
- 代理池/代理 API
- 本地 callback/helper HTTP server（如需全自动浏览器辅助）
