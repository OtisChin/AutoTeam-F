"""脱敏独立版 OAuth 补登录核心模块。

这个文件从当前项目的 OAuth 补登录链路复制/抽取出可复用的通用部分：

- PKCE 生成
- OAuth authorize URL 构造
- 回调 URL 解析
- authorization_code -> token 交换
- auth_session/cookie 复用的纯协议 OAuth 跳转
- token bundle 归一化与保存

所有端点、client_id、cookie 名称均可配置；默认值使用 example 域名和占位
client_id，便于复制到其他项目后再按目标环境填写。
"""

from __future__ import annotations

import base64
import dataclasses
import hashlib
import json
import os
import re
import secrets
import time
import urllib.parse
from collections.abc import Callable
from pathlib import Path
from typing import Any

DEFAULT_CALLBACK_PORT = 1455
DEFAULT_AUTH_URL = "https://auth.example.com/oauth/authorize"
DEFAULT_TOKEN_URL = "https://auth.example.com/oauth/token"
DEFAULT_CLIENT_ID = "REPLACE_WITH_OAUTH_CLIENT_ID"
DEFAULT_SCOPE = "openid email profile offline_access"
DEFAULT_SESSION_COOKIE_NAME = "__Secure-next-auth.session-token"
HELPER_LANDING_URL = "https://auth.example.com/"


class OAuthError(RuntimeError):
    """Base class for standalone OAuth relogin errors."""


class OAuthLoginRequired(OAuthError):
    """The protocol flow reached a login page instead of a callback URL."""

    def __init__(self, url: str = ""):
        self.url = url or ""
        message = "OAuth 停在登录页，未获取 authorization code"
        if self.url:
            message = f"{message}: {self.url}"
        super().__init__(message)


class OAuthPhoneRequired(OAuthError):
    """The provider requested phone verification."""

    def __init__(self, url: str = ""):
        self.url = url or ""
        message = "OAuth 需要手机号验证"
        if self.url:
            message = f"{message}: {self.url}"
        super().__init__(message)


class OAuthTokenBundleError(OAuthError):
    """Token response is missing the data needed by the caller."""


class PhoneSmsError(RuntimeError):
    """Phone/SMS provider error."""


@dataclasses.dataclass(frozen=True)
class OAuthConfig:
    """Config required for a reusable OAuth relogin flow."""

    client_id: str = DEFAULT_CLIENT_ID
    auth_url: str = DEFAULT_AUTH_URL
    token_url: str = DEFAULT_TOKEN_URL
    redirect_uri: str = f"http://127.0.0.1:{DEFAULT_CALLBACK_PORT}/auth/callback"
    scope: str = DEFAULT_SCOPE
    session_cookie_name: str = DEFAULT_SESSION_COOKIE_NAME
    account_cookie_name: str = "_account"
    device_cookie_name: str = "oai-did"
    auth_domains: tuple[str, ...] = ("auth.example.com", ".auth.example.com")
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"
    )

    @classmethod
    def from_env(cls, prefix: str = "OAUTH_RELOGIN_") -> OAuthConfig:
        """Create config from environment variables.

        Supported variables:
        OAUTH_RELOGIN_CLIENT_ID, OAUTH_RELOGIN_AUTH_URL,
        OAUTH_RELOGIN_TOKEN_URL, OAUTH_RELOGIN_REDIRECT_URI,
        OAUTH_RELOGIN_SCOPE, OAUTH_RELOGIN_SESSION_COOKIE_NAME,
        OAUTH_RELOGIN_AUTH_DOMAINS.
        """

        domains = os.getenv(f"{prefix}AUTH_DOMAINS", "")
        auth_domains = tuple(item.strip() for item in domains.split(",") if item.strip()) or cls().auth_domains
        return cls(
            client_id=os.getenv(f"{prefix}CLIENT_ID", DEFAULT_CLIENT_ID).strip() or DEFAULT_CLIENT_ID,
            auth_url=os.getenv(f"{prefix}AUTH_URL", DEFAULT_AUTH_URL).strip() or DEFAULT_AUTH_URL,
            token_url=os.getenv(f"{prefix}TOKEN_URL", DEFAULT_TOKEN_URL).strip() or DEFAULT_TOKEN_URL,
            redirect_uri=os.getenv(f"{prefix}REDIRECT_URI", cls().redirect_uri).strip() or cls().redirect_uri,
            scope=os.getenv(f"{prefix}SCOPE", DEFAULT_SCOPE).strip() or DEFAULT_SCOPE,
            session_cookie_name=(
                os.getenv(f"{prefix}SESSION_COOKIE_NAME", DEFAULT_SESSION_COOKIE_NAME).strip()
                or DEFAULT_SESSION_COOKIE_NAME
            ),
            auth_domains=auth_domains,
        )


def normalize_phone_sms_provider(raw: str | None = None) -> str:
    """Normalize phone/SMS provider names used by this standalone module."""

    value = str(raw or "").strip().lower().replace("-", "_")
    if value in {"hero_sms", "herosms", "hero"}:
        return "hero_sms"
    if value in {"smsbower", "sms_bower"}:
        return "smsbower"
    if value in {"smscloud", "sms_cloud", "sms_cloud_sbs"}:
        return "smscloud"
    if value in {"oasis", "oasis_sms", "oasissms", "oapi"}:
        return "oasis"
    if value in {"tujie", "tujie_sms", "tujie_cdk", "tujiecdk", "tj"}:
        return "tujie"
    return "phone_pool"


def normalize_sms_country(raw: str | None = None) -> str:
    """Normalize common country aliases to provider country IDs."""

    value = str(raw or "").strip().lower()
    if value in {"all", "any", "*", "全部", "所有", "不限", "global"}:
        return "all"
    if value and re.fullmatch(r"\d+", value):
        return value
    if value in {"", "us", "usa", "united_states", "united states", "+1"}:
        return "187"
    if value in {"gb", "uk", "united_kingdom", "united kingdom", "britain", "英国", "+44"}:
        return "44"
    if value in {"br", "bra", "brazil", "brasil", "巴西", "+55"}:
        return "73"
    if value in {"id", "idn", "indonesia", "indonesian", "印度尼西亚", "印尼", "+62"}:
        return "6"
    if value in {"co", "colombia", "colombian", "哥伦比亚", "哥伦比亚共和国", "+57"}:
        return "33"
    return value


@dataclasses.dataclass(frozen=True)
class PhoneSmsConfig:
    """接码配置。默认只内置 JSON 手机号池；HTTP 接码商通过 adapter 接入。"""

    provider: str = "phone_pool"
    country: str = "187"
    service: str = "dr"
    api_key: str = ""
    base_url: str = ""
    max_price: str = ""
    poll_attempts: int = 24
    poll_interval_seconds: float = 5.0

    @classmethod
    def from_env(cls, prefix: str = "OAUTH_RELOGIN_PHONE_SMS_") -> PhoneSmsConfig:
        attempts_raw = os.getenv(f"{prefix}POLL_ATTEMPTS", "24")
        interval_raw = os.getenv(f"{prefix}POLL_INTERVAL_SECONDS", "5")
        try:
            attempts = max(1, int(attempts_raw or "24"))
        except (TypeError, ValueError):
            attempts = 24
        try:
            interval = max(0.1, float(interval_raw or "5"))
        except (TypeError, ValueError):
            interval = 5.0
        return cls(
            provider=normalize_phone_sms_provider(os.getenv(f"{prefix}PROVIDER", "phone_pool")),
            country=normalize_sms_country(os.getenv(f"{prefix}COUNTRY", "187")),
            service=str(os.getenv(f"{prefix}SERVICE", "dr") or "dr").strip(),
            api_key=str(os.getenv(f"{prefix}API_KEY", "") or "").strip(),
            base_url=str(os.getenv(f"{prefix}BASE_URL", "") or "").strip(),
            max_price=str(os.getenv(f"{prefix}MAX_PRICE", "") or "").strip(),
            poll_attempts=attempts,
            poll_interval_seconds=interval,
        )

    def to_safe_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "country": self.country,
            "service": self.service,
            "api_key_present": bool(self.api_key),
            "api_key": redact_secret(self.api_key),
            "base_url": self.base_url,
            "max_price": self.max_price,
            "poll_attempts": self.poll_attempts,
            "poll_interval_seconds": self.poll_interval_seconds,
        }


@dataclasses.dataclass
class PhoneItem:
    """A phone number reserved for OAuth add-phone."""

    id: str
    phone_number: str
    sms_url: str = ""
    activation_id: str = ""
    otp: str = ""
    provider: str = "phone_pool"
    raw: dict[str, Any] = dataclasses.field(default_factory=dict)


def normalize_phone_key(phone: str) -> str:
    digits = re.sub(r"\D+", "", str(phone or ""))
    return digits or str(phone or "").strip().lower()


def _normalize_import_phone(phone: str) -> str:
    value = str(phone or "").strip()
    if not value:
        return ""
    if value.startswith("+"):
        return value
    digits = re.sub(r"\D+", "", value)
    if digits and digits == value:
        return f"+{digits}"
    return value


def parse_phone_import_lines(text: str) -> list[dict[str, str]]:
    """Parse phone-pool import text.

    Supported formats:
    ``+12025550111----https://sms.example/inbox`` or
    ``12025550111|https://sms.example/inbox``.
    """

    entries: list[dict[str, str]] = []
    for raw in str(text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if "|" in line:
            parts = re.split(r"\s*\|\s*", line, maxsplit=1)
        else:
            parts = re.split(r"\s*-{4,}\s*", line, maxsplit=1)
            if len(parts) != 2:
                match = re.match(r"^(.+?)\s+-\s+(https?://.+)$", line, re.I)
                if match:
                    parts = [match.group(1), match.group(2)]
        if len(parts) != 2:
            raise ValueError(f"导入格式无效: {line[:80]}")
        phone, sms_url = _normalize_import_phone(parts[0].strip()), parts[1].strip()
        if not phone or not sms_url:
            raise ValueError(f"导入格式无效: {line[:80]}")
        entries.append({"phone_number": phone, "sms_url": sms_url})
    return entries


class JsonPhonePoolProvider:
    """Standalone JSON-backed phone pool provider.

    The provider can manage reusable phone numbers and persist binding counts.
    OTP retrieval can be supplied by setting ``PhoneItem.otp`` in tests/tools or
    by passing ``phone_code_provider`` to ``run_oauth_relogin_flow``.
    """

    max_bindings_per_phone = 3

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"items": []}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise PhoneSmsError(f"手机号池 JSON 无效: {self.path}") from exc
        if isinstance(data, list):
            data = {"items": data}
        if not isinstance(data, dict):
            data = {"items": []}
        items = data.get("items")
        if not isinstance(items, list):
            data["items"] = []
        return data

    def _save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def import_phones(self, text: str) -> dict[str, Any]:
        parsed = parse_phone_import_lines(text)
        data = self._load()
        items = data["items"]
        known = {normalize_phone_key(item.get("phone_number") or item.get("phone") or "") for item in items}
        added = []
        for entry in parsed:
            key = normalize_phone_key(entry["phone_number"])
            if not key or key in known:
                continue
            item = {
                "id": secrets.token_hex(8),
                "phone_number": entry["phone_number"],
                "phone_key": key,
                "sms_url": entry["sms_url"],
                "status": "available",
                "bound_count": 0,
                "bound_emails": [],
                "created_at": time.time(),
                "updated_at": time.time(),
            }
            known.add(key)
            items.insert(0, item)
            added.append(item)
        self._save(data)
        return {"added_count": len(added), "total": len(items), "added": added}

    def acquire_phone(self, email: str = "") -> PhoneItem:
        data = self._load()
        now = time.time()
        for item in data["items"]:
            status = str(item.get("status") or "available").lower()
            count = int(item.get("bound_count") or len(item.get("bound_emails") or []))
            if status == "available" and count < self.max_bindings_per_phone:
                item["reserved_by"] = str(email or "").strip().lower()
                item["reserved_at"] = now
                item["updated_at"] = now
                self._save(data)
                return PhoneItem(
                    id=str(item.get("id") or ""),
                    phone_number=str(item.get("phone_number") or ""),
                    sms_url=str(item.get("sms_url") or ""),
                    provider="phone_pool",
                    raw=dict(item),
                )
        raise PhoneSmsError("手机号池没有可用号码")

    def wait_for_code(self, phone_item: PhoneItem) -> str:
        code = str(getattr(phone_item, "otp", "") or "").strip()
        if not code:
            raise PhoneSmsError("未提供手机号验证码；请传入 phone_code_provider 或接入接码商 adapter")
        return code

    def mark_bound(self, phone_item: PhoneItem, email: str) -> None:
        normalized_email = str(email or "").strip().lower()
        data = self._load()
        now = time.time()
        for item in data["items"]:
            if str(item.get("id") or "") != str(phone_item.id):
                continue
            bound = [str(value).strip().lower() for value in item.get("bound_emails") or [] if str(value).strip()]
            if normalized_email and normalized_email not in bound:
                bound.append(normalized_email)
            item["bound_emails"] = bound[: self.max_bindings_per_phone]
            item["bound_count"] = len(item["bound_emails"])
            item["status"] = "full" if item["bound_count"] >= self.max_bindings_per_phone else "available"
            item["last_used_at"] = now
            item["updated_at"] = now
            item["reserved_by"] = ""
            item["reserved_at"] = None
            self._save(data)
            return
        raise PhoneSmsError("手机号不存在，无法标记绑定")

    def release(self, phone_item: PhoneItem, *, reason: str = "") -> None:
        data = self._load()
        now = time.time()
        for item in data["items"]:
            if str(item.get("id") or "") != str(phone_item.id):
                continue
            item["reserved_by"] = ""
            item["reserved_at"] = None
            item["last_release_reason"] = str(reason or "")
            item["updated_at"] = now
            self._save(data)
            return


def redact_secret(value: object, *, prefix: int = 4, suffix: int = 4) -> str:
    """Return a log-safe representation of a token/secret."""

    text = str(value or "")
    if not text:
        return ""
    if len(text) <= prefix + suffix + 3:
        return "***"
    return f"{text[:prefix]}...{text[-suffix:]}"


def generate_pkce() -> tuple[str, str]:
    """Generate a PKCE code_verifier/code_challenge pair."""

    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode("ascii")
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode("ascii")
    return verifier, challenge


def build_authorization_url(
    config: OAuthConfig,
    *,
    code_challenge: str,
    state: str,
    native_oauth: bool = True,
    extra_params: dict[str, str] | None = None,
) -> str:
    """Build the OAuth authorize URL for a PKCE authorization-code flow."""

    params = {
        "client_id": config.client_id,
        "response_type": "code",
        "redirect_uri": config.redirect_uri,
        "scope": config.scope,
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "prompt": "login" if native_oauth else "consent",
    }
    if native_oauth:
        params["id_token_add_organizations"] = "true"
        params["codex_cli_simplified_flow"] = "true"
    if extra_params:
        params.update({str(key): str(value) for key, value in extra_params.items() if value is not None})
    return f"{config.auth_url}?{urllib.parse.urlencode(params)}"


def build_helper_fragment(token: str, port: str | int, auth_url: str) -> str:
    """Build a fragment consumed by ``oauth_helper_extension/content.js``."""

    return urllib.parse.urlencode(
        {
            "oauth_relogin_token": str(token or ""),
            "oauth_relogin_port": str(port or ""),
            "oauth_relogin_auth": str(auth_url or ""),
        }
    )


def build_helper_url(token: str, port: str | int, auth_url: str, *, landing_url: str = HELPER_LANDING_URL) -> str:
    """Build a helper landing URL that stores local helper config then redirects."""

    return f"{landing_url}#{build_helper_fragment(token, port, auth_url)}"


def parse_callback_url(input_text: str) -> dict[str, str]:
    """Parse code/state/error from a pasted or captured OAuth callback URL."""

    trimmed = str(input_text or "").strip()
    if not trimmed:
        raise ValueError("回调 URL 不能为空")

    candidate = trimmed
    if "://" not in candidate:
        if candidate.startswith("?"):
            candidate = "http://localhost" + candidate
        elif "=" in candidate:
            candidate = "http://localhost/?" + candidate
        elif any(ch in candidate for ch in "/?#:"):
            candidate = "http://" + candidate
        else:
            raise ValueError("无效的回调 URL")

    parsed_url = urllib.parse.urlparse(candidate)
    query = urllib.parse.parse_qs(parsed_url.query)
    fragment = urllib.parse.parse_qs(parsed_url.fragment)

    def first(name: str) -> str:
        return str((query.get(name) or fragment.get(name) or [""])[0]).strip()

    code = first("code")
    error = first("error") or first("error_description")
    if not code and not error:
        raise ValueError("回调 URL 中缺少 code")
    return {
        "code": code,
        "state": first("state"),
        "error": error,
        "raw_url": candidate,
    }


def _decode_jwt_payload(token: str) -> dict[str, Any]:
    token = str(token or "").strip()
    parts = token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1]
    payload += "=" * (-len(payload) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(payload.encode("ascii")).decode("utf-8"))
    except Exception:
        return {}


def _plan_from_claims(claims: dict[str, Any]) -> str:
    auth_claims = claims.get("https://api.openai.com/auth", {}) if isinstance(claims, dict) else {}
    if not isinstance(auth_claims, dict):
        return "unknown"
    return str(auth_claims.get("chatgpt_plan_type") or "unknown").strip().lower() or "unknown"


def _account_id_from_claims(*claim_groups: dict[str, Any]) -> str:
    for claims in claim_groups:
        auth_claims = claims.get("https://api.openai.com/auth", {}) if isinstance(claims, dict) else {}
        if isinstance(auth_claims, dict):
            account_id = str(auth_claims.get("chatgpt_account_id") or "").strip()
            if account_id:
                return account_id
    return ""


def build_token_bundle(token_data: dict[str, Any], *, fallback_email: str | None = None, now: float | None = None) -> dict[str, Any]:
    """Normalize an OAuth token endpoint response into a portable auth bundle."""

    if not isinstance(token_data, dict):
        raise OAuthTokenBundleError("token 响应必须是 JSON object")
    id_token = str(token_data.get("id_token") or "")
    access_token = str(token_data.get("access_token") or "")
    refresh_token = str(token_data.get("refresh_token") or "")
    id_claims = _decode_jwt_payload(id_token)
    access_claims = _decode_jwt_payload(access_token)

    try:
        expires_in = int(token_data.get("expires_in", 3600) or 3600)
    except (TypeError, ValueError):
        expires_in = 3600
    timestamp = time.time() if now is None else float(now)
    email = str(id_claims.get("email") or access_claims.get("email") or fallback_email or "").strip().lower()

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "id_token": id_token,
        "account_id": _account_id_from_claims(id_claims, access_claims),
        "email": email,
        "plan_type": _plan_from_claims(id_claims) if id_token else _plan_from_claims(access_claims),
        "expired": timestamp + expires_in,
    }


def exchange_auth_code(
    auth_code: str,
    code_verifier: str,
    *,
    config: OAuthConfig | None = None,
    fallback_email: str | None = None,
    http_post: Callable[..., Any] | None = None,
) -> dict[str, Any]:
    """Exchange an authorization code for tokens.

    ``http_post`` is injectable for tests or for projects that use a custom HTTP
    client. It must return an object with ``status_code`` and ``json()``.
    """

    config = config or OAuthConfig.from_env()
    if not str(auth_code or "").strip():
        raise OAuthError("auth_code 不能为空")
    if not str(code_verifier or "").strip():
        raise OAuthError("code_verifier 不能为空")

    if http_post is None:
        import requests

        http_post = requests.post

    response = http_post(
        config.token_url,
        data={
            "grant_type": "authorization_code",
            "client_id": config.client_id,
            "code": auth_code,
            "redirect_uri": config.redirect_uri,
            "code_verifier": code_verifier,
        },
        headers={
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": config.user_agent,
        },
        timeout=30,
    )
    status_code = int(getattr(response, "status_code", 0) or 0)
    if status_code != 200:
        body = str(getattr(response, "text", "") or "")[:240]
        raise OAuthError(f"OAuth token 交换失败 HTTP {status_code}: {body}")
    bundle = build_token_bundle(response.json(), fallback_email=fallback_email)
    if not bundle.get("access_token") or not bundle.get("refresh_token"):
        raise OAuthTokenBundleError("OAuth token 响应缺少 access_token 或 refresh_token")
    return bundle


def _headers(config: OAuthConfig, referer: str = "") -> dict[str, str]:
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "User-Agent": config.user_agent,
    }
    if referer:
        headers["Referer"] = referer
    return headers


def _callback_has_oauth_result(url: str) -> bool:
    parsed = urllib.parse.urlparse(str(url or ""))
    if "/auth/callback" not in (parsed.path or "").lower():
        return False
    query = urllib.parse.parse_qs(parsed.query)
    fragment = urllib.parse.parse_qs(parsed.fragment)
    return any((query.get(name) or fragment.get(name)) for name in ("code", "error", "error_description"))


def _extract_meta_refresh_url(html: str, base_url: str) -> str:
    import re

    match = re.search(
        r"<meta[^>]+http-equiv=[\"']?refresh[\"']?[^>]+content=[\"'][^\"']*url=([^\"'>\s]+)",
        str(html or ""),
        flags=re.I,
    )
    if not match:
        return ""
    return urllib.parse.urljoin(base_url, match.group(1).replace("&amp;", "&"))


def extract_session_token(auth_session: dict[str, Any], *, session_cookie_name: str = DEFAULT_SESSION_COOKIE_NAME) -> str:
    """Extract a reusable session token from a saved auth_session payload."""

    if not isinstance(auth_session, dict):
        return ""
    data = auth_session.get("data") if isinstance(auth_session.get("data"), dict) else auth_session
    context = auth_session.get("auth_context") if isinstance(auth_session.get("auth_context"), dict) else {}
    merged = {**data, **{key: value for key, value in context.items() if value}}
    direct = str(merged.get("sessionToken") or merged.get("session_token") or "").strip()
    if direct:
        return direct
    cookie_header = str(merged.get("cookie_header") or "")
    for part in cookie_header.split(";"):
        name, sep, value = part.strip().partition("=")
        if sep and name == session_cookie_name:
            return urllib.parse.unquote(value.strip())
    return ""


def seed_auth_cookies(session: Any, token: str, *, config: OAuthConfig, account_id: str = "", device_id: str = "") -> None:
    """Seed auth cookies on a requests-compatible session."""

    token = str(token or "").strip()
    if not token:
        return
    for domain in config.auth_domains:
        if len(token) > 3800:
            session.cookies.set(f"{config.session_cookie_name}.0", token[:3800], domain=domain, path="/")
            session.cookies.set(f"{config.session_cookie_name}.1", token[3800:], domain=domain, path="/")
        else:
            session.cookies.set(config.session_cookie_name, token, domain=domain, path="/")
        if account_id:
            session.cookies.set(config.account_cookie_name, account_id, domain=domain, path="/")
        if device_id:
            session.cookies.set(config.device_cookie_name, device_id, domain=domain, path="/")


def follow_authorization_redirects(
    session: Any,
    auth_url: str,
    *,
    expected_state: str,
    config: OAuthConfig | None = None,
    max_redirects: int = 18,
) -> dict[str, str]:
    """Follow an OAuth authorize URL until it reaches a callback result."""

    config = config or OAuthConfig.from_env()
    current_url = auth_url
    referer = ""
    final_body = ""
    for _index in range(max(1, int(max_redirects or 1))):
        if _callback_has_oauth_result(current_url):
            parsed = parse_callback_url(current_url)
            if parsed.get("state") and parsed["state"] != expected_state:
                raise OAuthError("OAuth state 不匹配")
            return parsed

        response = session.get(current_url, headers=_headers(config, referer), allow_redirects=False, timeout=30)
        final_body = str(getattr(response, "text", "") or "")
        status = int(getattr(response, "status_code", 0) or 0)
        location = str(getattr(response, "headers", {}).get("Location") or "")
        if status in {301, 302, 303, 307, 308} and location:
            referer = current_url
            current_url = urllib.parse.urljoin(current_url, location)
            continue

        meta_url = _extract_meta_refresh_url(final_body, current_url)
        if meta_url:
            referer = current_url
            current_url = meta_url
            continue

        lower_url = current_url.lower()
        lower_body = final_body[:3000].lower()
        if "add-phone" in lower_url or "phone verification" in lower_body or "add phone" in lower_body:
            raise OAuthPhoneRequired(current_url)
        if "log-in" in lower_url or "login" in lower_url or "sign in" in lower_body:
            raise OAuthLoginRequired(current_url)
        break
    raise OAuthError(f"OAuth 未在 {max_redirects} 次跳转内返回 callback")


def make_http_session(proxy_url: str | None = None) -> Any:
    """Create a requests-compatible session, preferring curl_cffi when installed."""

    try:
        from curl_cffi.requests import Session as CurlCffiSession  # type: ignore

        session = CurlCffiSession(impersonate="chrome")
    except Exception:
        import requests

        session = requests.Session()
    proxy = str(proxy_url or "").strip()
    if proxy:
        session.proxies = {"http": proxy, "https": proxy}
    return session


def oauth_from_auth_session(
    auth_session: dict[str, Any],
    *,
    config: OAuthConfig | None = None,
    email: str = "",
    account_id: str = "",
    device_id: str = "",
    proxy_url: str | None = None,
    session: Any | None = None,
) -> dict[str, Any]:
    """Run a protocol-only OAuth relogin from an existing auth_session/cookie."""

    config = config or OAuthConfig.from_env()
    session_token = extract_session_token(auth_session, session_cookie_name=config.session_cookie_name)
    if not session_token:
        raise OAuthError("auth_session 缺少可复用凭证")

    verifier, challenge = generate_pkce()
    state = secrets.token_urlsafe(16)
    auth_url = build_authorization_url(config, code_challenge=challenge, state=state, native_oauth=True)
    session = session or make_http_session(proxy_url)
    seed_auth_cookies(session, session_token, config=config, account_id=account_id, device_id=device_id)
    callback = follow_authorization_redirects(session, auth_url, expected_state=state, config=config)
    if callback.get("error"):
        raise OAuthError(f"OAuth 返回错误: {callback['error']}")
    return exchange_auth_code(callback["code"], verifier, config=config, fallback_email=email, http_post=session.post)


def save_auth_bundle(bundle: dict[str, Any], path: str | Path) -> str:
    """Save an auth bundle without logging or printing secrets."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        target.chmod(0o600)
    except Exception:
        pass
    return str(target)


def _safe_email_slug(email: str) -> str:
    value = str(email or "").strip().lower()
    slug = re.sub(r"[^a-z0-9_.+-]+", "-", value)
    return slug.strip("-") or "oauth-account"


def append_phone_binding_record(path: str | Path, *, phone_item: PhoneItem, email: str, now: float | None = None) -> str:
    """Append a non-secret phone binding audit record to JSON."""

    target = Path(path)
    if target.exists():
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise PhoneSmsError(f"手机号绑定记录 JSON 无效: {target}") from exc
    else:
        data = {"bindings": []}
    if not isinstance(data, dict):
        data = {"bindings": []}
    bindings = data.get("bindings")
    if not isinstance(bindings, list):
        bindings = []
        data["bindings"] = bindings
    bindings.append(
        {
            "email": str(email or "").strip().lower(),
            "phone_number": phone_item.phone_number,
            "phone_id": phone_item.id,
            "provider": phone_item.provider,
            "bound_at": time.time() if now is None else float(now),
        }
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)


def default_oauth_runner(**kwargs) -> dict[str, Any]:
    """Default protocol runner used by ``run_oauth_relogin_flow``.

    This runner expects an existing auth_session dict. Browser/UI automation and
    external SMS APIs are intentionally adapters so the copied module can be used
    in different projects without dragging the original app's task system.
    """

    auth_session = kwargs.get("auth_session")
    if not isinstance(auth_session, dict):
        raise OAuthError("默认 runner 需要 auth_session；浏览器登录请传入自定义 oauth_runner")
    return oauth_from_auth_session(
        auth_session,
        config=kwargs.get("config"),
        email=str(kwargs.get("email") or ""),
        account_id=str(kwargs.get("account_id") or ""),
        device_id=str(kwargs.get("device_id") or ""),
        proxy_url=kwargs.get("proxy_url"),
    )


def run_oauth_relogin_flow(
    *,
    email: str,
    password: str = "",
    output_dir: str | Path = "oauth-output",
    config: OAuthConfig | None = None,
    auth_session: dict[str, Any] | None = None,
    bind_phone: bool = False,
    sms_provider: Any | None = None,
    phone_code_provider: Callable[[PhoneItem], str] | None = None,
    oauth_runner: Callable[..., dict[str, Any]] | None = None,
    proxy_url: str | None = None,
    now: float | None = None,
) -> dict[str, Any]:
    """Run the standalone OAuth relogin orchestration and persist JSON files.

    End-to-end responsibility:
    1. load OAuth config
    2. optionally reserve a phone number
    3. expose a ``get_phone_code`` callback to the OAuth/browser runner
    4. persist the returned token bundle as JSON
    5. mark the phone as bound and write a binding audit JSON file

    ``oauth_runner`` is the integration point for either protocol auth_session
    login or browser automation in the target project. It must return a token
    bundle compatible with ``save_auth_bundle``.
    """

    normalized_email = str(email or "").strip().lower()
    if not normalized_email:
        raise OAuthError("email 不能为空")
    config = config or OAuthConfig.from_env()
    runner = oauth_runner or default_oauth_runner
    timestamp = time.time() if now is None else float(now)
    output_root = Path(output_dir)
    phone_item: PhoneItem | None = None
    phone_records_file = ""

    if bind_phone:
        if sms_provider is None:
            raise PhoneSmsError("bind_phone=True 时必须提供 sms_provider")
        phone_item = sms_provider.acquire_phone(normalized_email)

    def get_phone_code() -> str:
        if not phone_item:
            return ""
        if phone_code_provider is not None:
            code = str(phone_code_provider(phone_item) or "").strip()
            if not code:
                raise PhoneSmsError("phone_code_provider 未返回验证码")
            phone_item.otp = code
            return code
        return str(sms_provider.wait_for_code(phone_item) or "").strip()

    try:
        bundle = runner(
            email=normalized_email,
            password=password,
            config=config,
            auth_session=auth_session,
            phone_item=phone_item,
            get_phone_code=get_phone_code,
            proxy_url=proxy_url,
        )
        if not isinstance(bundle, dict):
            raise OAuthTokenBundleError("oauth_runner 未返回 token bundle")
        if not bundle.get("access_token") or not bundle.get("refresh_token"):
            raise OAuthTokenBundleError("OAuth token bundle 缺少 access_token 或 refresh_token")

        actual_email = str(bundle.get("email") or normalized_email).strip().lower()
        slug = _safe_email_slug(actual_email)
        auth_file = save_auth_bundle(bundle, output_root / "auths" / f"oauth-{slug}.json")

        if phone_item and sms_provider is not None:
            sms_provider.mark_bound(phone_item, actual_email)
            phone_records_file = append_phone_binding_record(
                output_root / "phone-bindings.json",
                phone_item=phone_item,
                email=actual_email,
                now=timestamp,
            )

        return {
            "status": "completed",
            "email": actual_email,
            "auth_file": auth_file,
            "phone_bound": bool(phone_item),
            "phone_number": phone_item.phone_number if phone_item else "",
            "phone_records_file": phone_records_file,
            "plan_type": str(bundle.get("plan_type") or "unknown"),
            "account_id": str(bundle.get("account_id") or ""),
        }
    except Exception:
        if phone_item and sms_provider is not None and hasattr(sms_provider, "release"):
            try:
                sms_provider.release(phone_item, reason="oauth_flow_failed")
            except Exception:
                pass
        raise
